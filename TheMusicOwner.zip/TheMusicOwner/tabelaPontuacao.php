<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>
<body>
    <a href="home.php">Home</a>
    <h1>Pontuação Total</h1>
    <table border="2">
        <thead>
            <tr>
                <th>GOSPEL</th>
                <th>INDIE</th>
                <th>MPB</th>
                <th>POP</th>
                <th>ROCK</th>
                <th>SERTANEJO</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <?php
                    session_start();

                    require_once "model/Partida.php";

                    $idUsuario = $_SESSION["idUsuario"];

                    if(!Partida::existe_generoId("GOSPEL", $idUsuario)){
                        Partida::cadastrar($idUsuario, "GOSPEL", 0);
                    }

                    if(!Partida::existe_generoId("INDIE", $idUsuario)){
                        Partida::cadastrar($idUsuario, "INDIE", 0);
                    }

                    if(!Partida::existe_generoId("MPB", $idUsuario)){
                        Partida::cadastrar($idUsuario, "MPB", 0);
                    }

                    if(!Partida::existe_generoId("POP", $idUsuario)){
                        Partida::cadastrar($idUsuario, "POP", 0);
                    }

                    if(!Partida::existe_generoId("ROCK", $idUsuario)){
                        Partida::cadastrar($idUsuario, "ROCK", 0);
                    }

                    if(!Partida::existe_generoId("SERTANEJO", $idUsuario)){
                        Partida::cadastrar($idUsuario, "SERTANEJO", 0);
                    }

                    $resultado = Partida::tabelaPontuacao($idUsuario);

                    echo "<td>" . $resultado[0]['sum(pontuacao)'] . "</td>";   
                    echo "<td>" . $resultado[1]['sum(pontuacao)'] . "</td>";
                    echo "<td>" . $resultado[2]['sum(pontuacao)'] . "</td>";
                    echo "<td>" . $resultado[3]['sum(pontuacao)'] . "</td>";
                    echo "<td>" . $resultado[4]['sum(pontuacao)'] . "</td>";
                    echo "<td>" . $resultado[5]['sum(pontuacao)'] . "</td>";
                ?>
            </tr>
        </tbody>
    </table>
</body>
</html>