<?php

header("Content-Type: application/json");

/* 
    A ideia aqui é que quando o usuário acessa a página será gerada uma lista aleatória com as imagens que ele pode percorrer.
    Ele começa a ver da imagem "0". Toda vez que pede para ir para outra imagem, o indice aumenta.
 */

session_start();

// Gera uma lista aleatória com as imagens a serem exibidas.
function gerarListaAleatoria()
{
    $lista = [];
    // Mudar o número máximo para a quantidade de imagens que tem...
    for ($i = 0; $i < 6; $i++) {
        $lista[] = sprintf("imagens/fotosPerfil/%d.png", $i + 1);
    }
    shuffle($lista);
    return $lista;
}

// Usar parametrosValidos se possível.
// Usei aqui esse tipo de IF para reduzir o número de comandos.
isset($_SESSION["lista"]) ? $lista = $_SESSION["lista"] : $lista = gerarListaAleatoria();
isset($_SESSION["index"]) ? $indexAtual = $_SESSION["index"] : $indexAtual = 0;

// Este é o tratamento
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $indexAtual++;
    if ($indexAtual >= count($lista)) {
        $indexAtual = 0;
    }
}

// Atualiza com a lista aleatória das imagens e o índice atual da imagem.
$_SESSION["lista"] = $lista;
$_SESSION["index"] = $indexAtual;

echo json_encode([
    "imagem" => $lista[$indexAtual]
]);
