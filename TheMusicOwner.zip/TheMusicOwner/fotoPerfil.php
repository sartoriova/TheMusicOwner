<?php
    require_once "model/FotoPerfil.php";
    require_once "configs/utils.php";

    if(parametrosValidos($_POST, ["fotoPerfil"])) {
        $resultado = FotoPerfil::listar_fotosPerfil();
        $i = array_rand($resultado);
        $fotoPerfil = $resultado[$i]['img'];
        
        echo json_encode(['img' => $fotoPerfil]);
        exit;
    }
?>
