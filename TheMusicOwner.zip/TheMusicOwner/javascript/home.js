var inputs = document.querySelectorAll("form input[type='button']");

inputs.forEach(function(input) {
    input.addEventListener("click", function(event) {
        var generoEscolhido = event.target.getAttribute("value");
        window.location.href = "armazenarGenero.php?genero=" + encodeURIComponent(generoEscolhido);
    });
});