<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>

<body>
    <h3>Cadastrando usuário:</h3>

    <img src="" alt="Imagem" style="border-radius: 50%; width: 200px; height: 200px;"><br>

    <form method="POST">
        <button>Experimentar outra</button>
    </form>

    <form method="POST">
        <!-- Essa é a parte importante... -->
        <input type="hidden" name="fotoPerfil" value="">
        <p>Nome de usuário:</p>
        <input type="text" name="nomeUsuario" autofocus="autofocus" required>
        <p>Senha:</p>
        <input type="password" name="senha" required><br><br>
        <button>Cadastrar</button>
    </form><br>

    <a href="index.php">Já tem uma conta? Entrar</a><br><br>

    <script>
        function trocarImagem() {
            let options = {
                method: "POST"
            };
            fetch("fotoPerfil.php", options)
                .then((d) => {
                    return d.json();
                })
                .then((d) => {
                    document.querySelector("input[name=fotoPerfil]").value = d.imagem;
                    document.querySelector("img").src = d.imagem;
                });
        }


        // Quando inicia o site, carrega uma imagem...
        trocarImagem();
        let form = document.querySelector("form");
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            trocarImagem();
        })
    </script>

    <?php
        require_once "model/Usuario.php";
        require_once "configs/utils.php";
       
        if(parametrosValidos($_POST, ["nomeUsuario", "senha", "fotoPerfil"])){
            $nomeUsuario = $_POST["nomeUsuario"]; 
            $senha = $_POST["senha"];
            $fotoPerfil = $_POST["fotoPerfil"];

            if(Usuario::existe_nomeUsuario($nomeUsuario)){
                echo "Este nome de usuário já está em uso!";
            }else{
                if(Usuario::cadastrar($nomeUsuario, $senha, $fotoPerfil)){
                    header("Location: index.php");
                } else{
                    echo "Houve erro no cadastro do(a) " . $nome . "!";
                }
            }
        }
    ?> 
</body>

</html>