<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/cadastro.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
    <header>
        <!-- <img class="header-image" src="imagens/logotipo.png" alt="Logotipo"  width="70" height="90"> -->
        <div class="header-text">
            <h1>THE MUSIC OWNER</h1>
        </div>
    </header>

    <section><br><br>
        <div class="text-block">
            <center>
                <img class="img_login" src="" alt="Imagem do cadastro" width="200px" height="200px"><br><br>
                <form method="POST">
                    <button class="my-button2">Experimentar outra</button>
                </form>
            </center>


            <h3>
                <form method="POST">
                    <!-- Essa é a parte importante... -->
                    <input type="hidden" name="fotoPerfil" value="">

                    <label for="nomeUsuario">Nome de usuário:</label><br><br>
                    <input type="text" placeholder="Digite seu nome de usuário" name="nomeUsuario" autofocus="autofocus" required><br><br>

                    <label for="senha">Senha:</label><br><br>
                    <input type="password" placeholder="Digite sua senha" name="senha" required><br><br>

                    <center>
                        <button class="my-button">Cadastrar-se</button><br><br><br>
                        <a href="index.php">Já tem uma conta? Entrar</a>
                    </center>
                </form>
            </h3>
        </div>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>

    <script>
        function trocarImagem() {
            let options = {
                method: "POST"
            };
            fetch("fotoPerfil.php", options)
                .then((d) => {
                    return d.json();
                })
                .then((d) => {
                    document.querySelector("input[name=fotoPerfil]").value = d.imagem;
                    document.querySelector("img").src = d.imagem;
                });
        }


        // Quando inicia o site, carrega uma imagem...
        trocarImagem();
        let form = document.querySelector("form");
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            trocarImagem();
        })
    </script>

    <?php
        require_once "model/Usuario.php";
        require_once "configs/utils.php";
       
        if(parametrosValidos($_POST, ["nomeUsuario", "senha", "fotoPerfil"])){
            $nomeUsuario = $_POST["nomeUsuario"]; 
            $senha = $_POST["senha"];
            $fotoPerfil = $_POST["fotoPerfil"];

            if(Usuario::existe_nomeUsuario($nomeUsuario)){
                echo "Este nome de usuário já está em uso!";
            }else{
                if(Usuario::cadastrar($nomeUsuario, $senha, $fotoPerfil)){
                    header("Location: index.php");
                } else{
                    echo "Houve erro no cadastro do(a) " . $nome . "!";
                }
            }
        }
    ?> 
</body>

</html>