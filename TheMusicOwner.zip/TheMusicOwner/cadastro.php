<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>

<body>
    <h3>Cadastrando usuário:</h3>

    <div class="fotoPerfil">
        <?php
            session_start();

            require_once "model/FotoPerfil.php";
            require_once "configs/utils.php";

            $resultado = FotoPerfil::listar_fotosPerfil();
            $i = array_rand($resultado);
        ?>

        <img id="fotoPerfil" src="<?php echo $resultado[$i]['img']; ?>" style="border-radius: 50%; width: 300px; height: 300px;"><br>
        <button id="btnTroca">Experimentar outra</button>
    </div>

    <form method="POST">
        <input type="hidden" name="fotoPerfil" value="<?php echo $resultado[$i]['img']; ?>">
        <p>Nome de usuário:</p>
            <input type="text" name="nomeUsuario" autofocus="autofocus" required>
        <p>Senha:</p>
            <input type="password" name="senha" required><br><br>
        <button>Cadastrar</button>
    </form><br>

    <script>
        document.getElementById("btnTroca").addEventListener("click", function() {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "fotoPerfil.php", true);
            xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var newImage = JSON.parse(xhr.responseText);
                        document.getElementById("fotoPerfil").src = newImage.img;
                    }
                }
            };

            xhr.send("fotoPerfil=true");
        });
    </script>

    <?php
        require_once "model/Usuario.php";
       
        if(parametrosValidos($_POST, ["nomeUsuario", "senha", "fotoPerfil"])){
            $nomeUsuario = $_POST["nomeUsuario"]; 
            $senha = $_POST["senha"];
            $fotoPerfil = $_POST["fotoPerfil"];

            if(Usuario::existe_nomeUsuario($nomeUsuario)){
                echo "Este nome de usuário já está em uso!";
            }else{
                if(Usuario::cadastrar($nomeUsuario, $senha, $fotoPerfil)){
                    header("Location: index.php");
                } else{
                    echo "Houve erro no cadastro do(a) " . $nome . "!";
                }
            }
        }
    ?> 
</body>

</html>