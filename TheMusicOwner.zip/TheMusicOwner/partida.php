<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>

<body>
    <a href="home.php">Home</a><br>
    <div class="imagem">
        <?php
            session_start();

            require_once "model/GeneroCantor.php";
            require_once "model/Partida.php";
            require_once "configs/utils.php";
            require_once "configs/methods.php";
            require_once "verificaLogin.php";

            $tipoGenero = $_SESSION["tipoGenero"];

            $resultado = GeneroCantor::listar_cantoresGenero($tipoGenero);

            if (!parametrosValidos($_SESSION, ["i"])) {
                $_SESSION["i"] = 0; 
                $_SESSION["pontuacao"] = 0;

                $i = $_SESSION["i"];
        
                echo "<img src=" . $resultado[$i]['img'] . "><br><br>";
            }else{
                $_SESSION["i"]++;
    
                $i = $_SESSION["i"];
    
                $pontuacao = $_SESSION["pontuacao"];
    
                $nomeCantor_usuario = mb_strtoupper($_POST["nomeCantor"]);
    
                $nomeCantor = $resultado[$i-1]["nome"];
    
                if($nomeCantor == $nomeCantor_usuario){
                    $_SESSION["pontuacao"]++;
                    $pontuacao = $_SESSION["pontuacao"];
                }
    
                if($i < count($resultado)){
                    echo "<img src=" . $resultado[$i]['img'] . "><br><br>";
                } else {
                    unset($_SESSION["i"]);

                    $idUsuario = $_SESSION["idUsuario"];

                    $resultado = Partida::cadastrar($idUsuario, $tipoGenero, $pontuacao);
                    if(!$resultado){
                        echo "<p>Erro ao cadastrar partida!</p>";
                    }

                    header("Location: pontuacaoFinal.php");
                }
            }
        ?>
    </div>

    <form method="POST">
        <input type=text name="nomeCantor" autofocus="autofocus" required><br><br>
        <button>Próximo</button>
    </form>
</body>

</html>