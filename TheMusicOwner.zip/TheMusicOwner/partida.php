<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="imagens/logotipo.png">
    <title>The Music Owner - Partida</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/partida.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>

<body>
    <header>
        <a href="home.php">
            <div class="left-icon">
                <img class="header-image" src="imagens/logotipo.png" alt="Imagem no Cabeçalho" width="80" height="97" style="margin-left: -20px; margin-top: 7px;">
            </div>
        </a>

        <div class="center-icon">
            <h1 style="font-size: 50px;">THE MUSIC OWNER</h1>
        </div>

        <div class="right-icon">
            <a href="home.php"> 
                <img class="header-image" src="imagens/home.png" alt="#" width="70" height="70" style="margin-right: 20px;"> 
            </a>
        </div>
    </header>

    <section style="height: 100%; margin-top: 3px;">
        <center>
            <?php
                session_start();

                require_once "model/GeneroCantor.php";
                require_once "model/Partida.php";
                require_once "model/GeneroMusical.php";
                require_once "configs/utils.php";
                require_once "configs/verificaLogin.php";

                $tipoGenero = $_SESSION["tipoGenero"];

                $resultado = GeneroCantor::listar_cantoresGenero($tipoGenero);

                if (!parametrosValidos($_SESSION, ["i"])) {
                    $_SESSION["i"] = 0; 
                    $_SESSION["pontuacao"] = 0;

                    $i = $_SESSION["i"];

                    echo "<button class='button1'>" . $i+1 . "</button>";
                    echo "<img class='image-central' style='border-radius: 50%; width: 520px; height: 520px; margin-top: 20px;' src=" . $resultado[$i]['img'] . "><br><br>";
                }else{
                    $_SESSION["i"]++;
                
                    $i = $_SESSION["i"];

                    echo "<button class='button1'>" . $i+1 . "</button>";
                
                    $pontuacao = $_SESSION["pontuacao"];
                
                    $nomeCantor_usuario = mb_strtoupper($_POST["nomeCantor"]);
                
                    $nomeCantor = $resultado[$i-1]["nome"];
                
                    if($nomeCantor == $nomeCantor_usuario){
                        $_SESSION["pontuacao"]++;
                        $pontuacao = $_SESSION["pontuacao"];
                    }

                    if($i < count($resultado)){
                        echo "<img class='image-central' style='border-radius: 50%; width: 520px; height: 520px; margin-top: 20px;' src=" . $resultado[$i]['img'] . "><br><br>";
                    } else {
                        unset($_SESSION["i"]);
                
                        $idUsuario = $_SESSION["idUsuario"];
                
                        $resultado = Partida::cadastrar($idUsuario, $tipoGenero, $pontuacao);
                        if(!$resultado){
                            echo "<p>Erro ao cadastrar partida!</p>";
                        }
                
                        $classificacao = "";
                        echo $pontuacao;
                
                        if($pontuacao < 10){
                            $classificacao = "Insuficiente";
                            $_SESSION["classificacao"] = $classificacao;
                        }elseif ( ($pontuacao >= 10) && ($pontuacao < 17) ){
                            $classificacao = "Suficiente";
                            $_SESSION["classificacao"] = $classificacao;
                        }else{
                            $classificacao = "Mais que suficiente";
                            $_SESSION["classificacao"] = $classificacao;
                        }
                
                        $resultado = GeneroMusical::alterar($tipoGenero, $classificacao);
                        if(!$resultado){
                            echo "<p>Erro ao alterar gênero musical!</p>";
                        }
                
                        header("Location: pontuacaoFinal.php");
                    }
                }
            ?>

            <form method="POST">
                <input type=text name="nomeCantor" autofocus="autofocus" required style="font-family: Cuprum; padding: 1px 2px;"><br><br>
                <button style="font-weight: bold; padding: 10px 20px; font-size: 16px; background-color: rgba(21.010938361287117, 0, 150.0781300663948, 1); color: rgba(255, 255, 255, 1); border: none; border-radius: 5px; cursor: pointer; font-family: PT Mono;">Próximo</button>
            </form>
        </center>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
    crossorigin="anonymous"></script>
</body>

</html>