<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="imagens/logotipo.png">
    <title>The Music Owner - Pontuação final</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/pontuacaoFinal.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
    <header>
        <a href="home.php">
            <div class="left-icon">
                <img class="header-image" src="imagens/logotipo.png" alt="Imagem no Cabeçalho" width="80" height="97" style="margin-left: -10px; margin-top: 225px;">
            </div>
        </a>

        <div class="center-icon">
            <h1 style="font-size: 50px; font-weight: normal;">THE MUSIC OWNER</h1>
        </div>

        <div class="right-icon">
            <a href="home.php"> 
                <img class="header-image" src="imagens/home.png" alt="" width="70" height="70" style="margin-right: 20px;"> 
            </a>
        </div>
    </header>

    <section><br>
        <form><br>
            <div class="text-block" style="margin-top: 20px;">
                <h3>
                    <p style="font-weight: normal;">Sua pontuação final foi</p>

                    <div class="pontuacao">
                        <p>
                            <?php
                                session_start();

                                require_once "configs/utils.php";

                                $pontuacao = $_SESSION["pontuacao"];
                                echo "<h2 style='font-weight: normal; text-shadow: 0px 0px 0 #000, 0px 0px 0 #000, 0px 0px 0 #000, 4px 4px 0 #000;'>$pontuacao/20</h2>";
                            ?>
                        </p>
                    </div>

                    <?php
                        echo "<a style='font-weight: normal'>Você errou " . 20-$pontuacao . " cantor(es)</a>";
                    ?>

                    <div class="icon-container2">

                    <?php
                        $classificacao = $_SESSION["classificacao"];

                        if($classificacao == "Insuficiente"){
                    ?>
                            <img src="imagens/estrela.png" alt="Ícone 1" class="icon1" width="120" height="90">
                            <img src="imagens/estrelaCinza.png" alt="Ícone 2" class="icon2" width="120" height="90">
                            <img src="imagens/estrelaCinza.png" alt="Ícone 3" class="icon3" width="120" height="90" style="margin-left: 55px;">
                    <?php
                        }elseif($classificacao == "Suficiente"){
                    ?>
                            <img src="imagens/estrela.png" alt="Ícone 1" class="icon1" width="120" height="90">
                            <img src="imagens/estrela.png" alt="Ícone 2" class="icon2" width="120" height="90">
                            <img src="imagens/estrelaCinza.png" alt="Ícone 3" class="icon3" width="120" height="90" style="margin-left: 55px;">
                    <?php
                        }else{
                    ?>
                            <img src="imagens/estrela.png" alt="Ícone 1" class="icon1" width="120" height="90">
                            <img src="imagens/estrela.png" alt="Ícone 2" class="icon2" width="120" height="90">
                            <img src="imagens/estrela.png" alt="Ícone 3" class="icon3" width="120" height="90" style="margin-left: 55px;">
                    <?php
                        }
                    ?>
                    </div><br><br><br><br>

                    <button class="my-button" style="font-weight: bold; top: -180px;">
                        <a href="partida.php" style="text-decoration: none; color: white; top: 0px;">Tentar novamente</a>
                    </button>
                </h3>
            </div>
        </form>
    </section>

   <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
</body>
</html>