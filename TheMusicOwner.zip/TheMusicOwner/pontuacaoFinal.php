<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>
<body>
   <p>Sua pontuação final foi</p>
   
   <?php
        session_start();

        require_once "configs/utils.php";

        $pontuacao = $_SESSION["pontuacao"];
        echo "<h1>$pontuacao/20</h1>";
   ?>

   <a href="partida.php">Tentar novamente</a><br>
   <a href="home.php">Home</a>
</body>
</html>