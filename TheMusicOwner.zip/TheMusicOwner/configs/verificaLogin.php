<?php
    if(!parametrosValidos($_SESSION, ["idUsuario"])){
        header("Location: index.php");
    }
?>