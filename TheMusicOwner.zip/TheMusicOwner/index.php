<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="imagens/logotipo.png">
    <title>The Music Owner - Entre ou cadastre-se</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>

    <header>
        <img class="header-image" src="imagens/logotipo.png" alt="Logotipo" width="80" height="97" style="margin-left: -20px; margin-top: -10px;">
        <div class="header-text">
            <h1 style="font-weight: normal; font-size: 50px;">THE MUSIC OWNER</h1>
        </div> 
    </header>

    <section><br><br>
        <form method="POST"><br>
            <div class="text-block">
                <h2><br>
                    <label for="nomeUsuario">Nome de usuário:</label><br><br>
                    <input type="text" placeholder="Digite seu nome de usuário" name="nomeUsuario" autofocus="autofocus" required><br><br>

                    <label for="senha">Senha:</label><br><br>
                    <input type="password" placeholder="Digite sua senha" name="senha" required><br><br><br>

                    <center>
                        <button class="my-button" style="font-weight: bold;">Entrar</button><br><br><hr style="border-color: #00978E;"><br>
                        <button class="my-button2">
                            <a href="cadastro.php" style="text-decoration: none; color: white; font-weight: bold;">Cadastre-se</a>
                        </button>
                    </center>
                </h2>
            </div>
        </form>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>

    <?php
        session_start();

        require_once "model/Usuario.php";
        require_once "configs/utils.php";
       
        if(parametrosValidos($_POST, ["nomeUsuario", "senha"])){
            $nomeUsuario = $_POST["nomeUsuario"];
            $senha = $_POST["senha"];
    
            $resultado = Usuario::fazerLogin($nomeUsuario, $senha);
    
            if(!Usuario::fazerLogin($nomeUsuario, $senha)) {
                echo "<div style='background-color: #f8d7da; color: #721c24; padding: 7px; border: 1px solid #f5c6cb; border-radius: 5px; margin-top: -742px;'>Nome de usuário ou senha incorretos!</div>";
            }else{
                $_SESSION["idUsuario"] = $resultado;
                header("Location: home.php");
            }
        }
    ?>
</body>

</html>