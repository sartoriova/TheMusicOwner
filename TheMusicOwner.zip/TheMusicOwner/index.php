<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>

<body>
    <h3>Logando usuário:</h3>

    <form method="POST">
        <p>Nome de usuário:</p>
            <input type="text" name="nomeUsuario" autofocus="autofocus" required>
        <p>Senha:</p>
            <input type="password" name="senha" required><br><br>
        <button>Entrar</button>
    </form><br>

    <a href="cadastro.php">Não tem uma conta? Cadastre-se</a><br><br>

    <?php
        session_start();

        require_once "model/Usuario.php";
        require_once "configs/utils.php";
       
        if(parametrosValidos($_POST, ["nomeUsuario", "senha"])){
            $nomeUsuario = $_POST["nomeUsuario"];
            $senha = $_POST["senha"];
    
            $resultado = Usuario::fazerLogin($nomeUsuario, $senha);
    
            if(!Usuario::fazerLogin($nomeUsuario, $senha)) {
                echo "Nome de usuário ou senha incorretos!";
            }else{
                $_SESSION["idUsuario"] = $resultado;
                header("Location: home.php");
            }
        }
    ?>
</body>

</html>