<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>

    <header>
        <img class="header-image" src="imagens/logotipo.png" alt="Logotipo" width="70" height="82">
        <div class="header-text">
            <h1>THE MUSIC OWNER</h1>
        </div>
    </header>

    <section><br><br>
        <form method="POST"><br>
            <div class="text-block">
                <h2><br>
                    <label for="nomeUsuario">Nome de usuário:</label><br><br>
                    <input type="text" placeholder="Digite seu nome de usuário" name="nomeUsuario" autofocus="autofocus" required><br><br>

                    <label for="senha">Senha:</label><br><br>
                    <input type="password" placeholder="Digite a sua senha" name="senha" required><br><br><br>

                    <center>
                        <button class="my-button">Entrar</button><br><br><hr style="border-color: #00978E;"><br>
                        <button class="my-button2">
                            <a href="cadastro.php" style="text-decoration: none; color: white;">Cadastre-se</a>
                        </button>
                    </center>
                </h2>
            </div>
        </form>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>

    <?php
        session_start();

        require_once "model/Usuario.php";
        require_once "configs/utils.php";
       
        if(parametrosValidos($_POST, ["nomeUsuario", "senha"])){
            $nomeUsuario = $_POST["nomeUsuario"];
            $senha = $_POST["senha"];
    
            $resultado = Usuario::fazerLogin($nomeUsuario, $senha);
    
            if(!Usuario::fazerLogin($nomeUsuario, $senha)) {
                echo "Nome de usuário ou senha incorretos!";
            }else{
                $_SESSION["idUsuario"] = $resultado;
                header("Location: home.php");
            }
        }
    ?>
</body>

</html>