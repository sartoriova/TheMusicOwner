<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>

<body>
    <a href = "home.php">Home</a>

    <h3>Editando usuário:</h3>

    <?php
        require_once "model/Usuario.php";
        require_once "configs/utils.php";

        $idUsuario = 0;
        $usuario = [];

        if(parametrosValidos($_GET, ["editarDados"])){
            $idUsuario = $_GET["editarDados"];

            $usuario = Usuario::retornaUsuario($idUsuario);
        }
    ?>

    <img src="" alt="Imagem" style="border-radius: 50%; width: 200px; height: 200px;"><br>

    <form method="POST">
        <button>Experimentar outra</button>
    </form>

    <form method="POST">
        <!-- Essa é a parte importante... -->
        <input type="hidden" name="fotoPerfil" value="">
        <p>Nome de usuário:</p>
        <input type="text" name="nomeUsuario" autofocus="autofocus" value="<?php echo $usuario[0]["nomeUsuario"];?>" required>
        <p>Senha atual:</p>
        <input type="password" name="senhaAtual" required><br>
        <p>Senha nova:</p>
        <input type="password" name="senhaNova" required><br><br>
        <button type="submit">Editar</button>
    </form><br>

    <script>
        function trocarImagem() {
            let options = {
                method: "POST"
            };
            fetch("fotoPerfil.php", options)
                .then((d) => {
                    return d.json();
                })
                .then((d) => {
                    document.querySelector("input[name=fotoPerfil]").value = d.imagem;
                    document.querySelector("img").src = d.imagem;
                });
        }


        // Quando inicia o site, carrega uma imagem...
        trocarImagem();
        let form = document.querySelector("form");
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            trocarImagem();
        })
    </script>

    <?php
        if(parametrosValidos($_POST, ["nomeUsuario", "senhaAtual", "senhaNova", "fotoPerfil"])){
            $nomeUsuario = $_POST["nomeUsuario"]; 
            $senhaAtual = $_POST["senhaAtual"];
            $senhaNova = $_POST["senhaNova"];
            $fotoPerfil = $_POST["fotoPerfil"];

            if(Usuario::existe_nomeUsuario_id($nomeUsuario, $idUsuario)){
                echo "Este nome de usuário já está em uso!";
            }else{
                if(Usuario::alterar($idUsuario, $nomeUsuario, $senhaAtual, $senhaNova, $fotoPerfil)){
                    header("Location: perfil.php");
                } else{
                    echo "Houve erro na edição do(a) " . $nome . "!";
                }
            }
        }
    ?> 
</body>
</html>