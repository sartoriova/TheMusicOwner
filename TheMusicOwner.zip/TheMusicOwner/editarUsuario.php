<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="imagens/logotipo.png">
    <title>The Music Owner - Editar meus dados</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/cadastro.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>

<body>
    <header>
        <div class="header-text">
            <h1 style="font-size: 50px; font-weight: normal; margin-top: 20px;">THE MUSIC OWNER</h1>
        </div>
    </header>

    <section><br><br>
        <div class="text-block" style="height: 100%;">
            <center>
                <img class="img_login" src="" alt="Imagem do cadastro" width="200px" height="200px"><br><br>
                <form method="POST">
                    <button class="my-button2" style="font-weight: bold;">Experimentar outra</button>
                </form>
            </center>

            <h3>
                <form method="POST">
                    <input type="hidden" name="fotoPerfil" value="">

                    <label for="nomeUsuario">Nome de usuário:</label><br><br>
                    <input type="text" placeholder="Digite seu nome de usuário" name="nomeUsuario" autofocus="autofocus" required><br><br>

                    <label for="senha">Senha atual:</label><br><br>
                    <input type="password" placeholder="Digite sua senha" name="senhaAtual" required><br><br>

                    <label for="senha">Senha nova:</label><br><br>
                    <input type="password" placeholder="Digite sua senha" name="senhaNova" required><br><br>

                    <center>
                        <button class="my-button" style="font-weight: bold;">Editar</button>
                    </center>
                </form>
            </h3>
        </div>

        <a href="home.php">
            <img class="header-image" src="imagens/logotipo.png" alt="Logotipo" width="80" height="90" style="position: relative; top: -773px; margin-left: -10px; margin-top: 13px;">
        </a>
    </section>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>

    <script>
        function trocarImagem() {
            let options = {
                method: "POST"
            };
            fetch("fotoPerfil.php", options)
                .then((d) => {
                    return d.json();
                })
                .then((d) => {
                    document.querySelector("input[name=fotoPerfil]").value = d.imagem;
                    document.querySelector("img").src = d.imagem;
                });
        }

        trocarImagem();
        let form = document.querySelector("form");
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            trocarImagem();
        })
    </script>

    <?php
        require_once "model/Usuario.php";
        require_once "configs/utils.php";

        $idUsuario = 0;
        $usuario = [];

        if(parametrosValidos($_GET, ["editarDados"])){
            $idUsuario = $_GET["editarDados"];

            $usuario = Usuario::retornaUsuario($idUsuario);
        }
    ?>

    <?php
        if(parametrosValidos($_POST, ["nomeUsuario", "senhaAtual", "senhaNova", "fotoPerfil"])){
            $nomeUsuario = $_POST["nomeUsuario"]; 
            $senhaAtual = $_POST["senhaAtual"];
            $senhaNova = $_POST["senhaNova"];
            $fotoPerfil = $_POST["fotoPerfil"];

            if(Usuario::existe_nomeUsuario_id($nomeUsuario, $idUsuario)){
                echo "<div style='background-color: #f8d7da; color: #721c24; padding: 7px; border: 1px solid #f5c6cb; border-radius: 5px; margin-top: -794px;'>Este nome de usuário já está em uso!</div>";
            }else{
                if(Usuario::alterar($idUsuario, $nomeUsuario, $senhaAtual, $senhaNova, $fotoPerfil)){
                    header("Location: perfil.php");
                } else{
                    echo "<div style='background-color: #f8d7da; color: #721c24; padding: 7px; border: 1px solid #f5c6cb; border-radius: 5px; margin-top: -794px;'>Senha atual incorreta!</div>";
                }
            }
        }
    ?> 
</body>
</html>