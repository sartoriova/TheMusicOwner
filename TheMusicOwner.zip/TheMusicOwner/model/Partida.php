<?php
    require_once "configs/BancoDados.php";

    Class Partida {

        public static function tabelaPontuacao($idUsuario){
            try{
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select tipoGenero, sum(pontuacao) from partida where idUsuario = ? group by tipoGenero;
                ");
                $sql->execute([$idUsuario]);
    
                return $sql->fetchAll();
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        public static function cadastrar($idUsuario, $tipoGenero, $pontuacao){
            try{
                date_default_timezone_set("America/Sao_Paulo");
                $data = date("y-m-d");

                $hora = date("H:i") . ":00";
                
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    insert into partida (idUsuario, tipoGenero, data, hora, pontuacao) values (?, ?, ?, ?, ?)
                ");
                $sql->execute([$idUsuario, $tipoGenero, $data, $hora, $pontuacao]);

                if($sql->rowCount() > 0){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        // public static function existePartida($idUser, $tipoGenero, $data, $hora){
        //     try{
        //         $conexao = Conexao::getConexao();
        //         $sql = $conexao->prepare("
        //             select count(*) from partida where idUser = ? and tipoGenero = ? and data = ? and hora = ?
        //         ");
        //         $sql->execute([$idUser, $tipoGenero, $data, $hora]);

        //         if($sql->fetchColumn() > 0){
        //             return true;
        //         }else{
        //             return false;
        //         }
        //     }catch(Exception $e){
        //         echo $e->getMessage();
        //         exit;
        //     }
        // }

        public static function existe_generoId($tipoGenero, $idUsuario){
            try{
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select count(*) from partida where tipoGenero = ? and idUsuario = ?
                ");
                $sql->execute([$tipoGenero, $idUsuario]);

                if($sql->fetchColumn() > 0){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

    }
?>