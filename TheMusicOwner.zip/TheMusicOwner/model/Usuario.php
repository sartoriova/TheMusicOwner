<?php
    require_once "configs/BancoDados.php";

    Class Usuario {

        public static function existe_nomeUsuario_id($nomeUsuario, $id){
            try{
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select count(*) from usuario where nomeUsuario = ? and id not in (?)
                ");
                $sql->execute([$nomeUsuario, $id]);
    
                if($sql->fetchColumn() > 0){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        public static function existe_nomeUsuario($nomeUsuario){
            try{
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select count(*) from usuario where nomeUsuario = ?
                ");
                $sql->execute([$nomeUsuario]);
    
                if($sql->fetchColumn() > 0){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        public static function cadastrar($nomeUsuario, $senha, $fotoPerfil){
            try{
                $senhaCriptografada = password_hash($senha, PASSWORD_BCRYPT);

                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    insert into usuario (nomeUsuario, senha, fotoPerfil) values (?, ?, ?)
                ");
                $sql->execute([$nomeUsuario, $senhaCriptografada, $fotoPerfil]);

                if($sql->rowCount() > 0){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        public static function fazerLogin($nomeUsuario, $senha){
            try {
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select * from usuario where nomeUsuario = ?
                ");
                $sql->execute([$nomeUsuario]);

                $resultado = $sql->fetchAll();

                if($resultado == []){
                    return false;
                }else{
                    if(password_verify($senha, $resultado[0]["senha"])){
                        return $resultado[0]["id"];
                    }else{
                        return false;
                    }
                }
            } catch (Exception $e) {
                echo $e->getMessage();
                exit;
            }
        }

        public static function retornaUsuario($id){
            try{
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select * from usuario where id = ?
                ");
                $sql->execute([$id]);

                return $sql->fetchAll();
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        public static function listarUm($id){
            try{
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select nomeUsuario, fotoPerfil from usuario where id = ?
                ");
                $sql->execute([$id]);

                return $sql->fetchAll();
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        public static function alterar($id, $nomeUsuario, $senhaAtual, $senhaNova, $fotoPerfil){
            try{ 
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select * from usuario where id = ?
                ");
                $sql->execute([$id]);

                $resultado = $sql->fetchAll();

                if(password_verify($senhaAtual, $resultado[0]["senha"])){
                    $senhaCriptografada = password_hash($senhaNova, PASSWORD_BCRYPT);

                    $sql1 = $conexao->prepare("
                        update usuario set nomeUsuario = ?, senha = ?, fotoPerfil = ? where id = ?
                    ");
                    $sql1->execute([$nomeUsuario, $senhaCriptografada, $fotoPerfil, $id]);

                    if($sql1->rowCount() > 0){
                        return true;
                    }else{
                        return false;
                    }
                }else{
                    return false;
                }
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

        public static function deletar($id){
            try{
                $conexao = Conexao::getConexao();

                $sql = $conexao->prepare("
                    delete from partida where idUsuario = ?
                ");
                $sql1 = $conexao->prepare("
                    delete from usuario where id = ?
                ");

                $sql->execute([$id]);
                $sql1->execute([$id]);

                if($sql1->rowCount() > 0){
                    return true;
                }else{
                    return false;
                }
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }
        
    }
?>