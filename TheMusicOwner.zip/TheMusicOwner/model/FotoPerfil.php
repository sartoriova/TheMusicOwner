<?php
    require_once "configs/BancoDados.php";

    Class FotoPerfil {

        public static function listar_fotosPerfil(){
            try{
                $conexao = Conexao::getConexao();
                $sql = $conexao->prepare("
                    select * from fotoPerfil
                ");
                $sql->execute([]);
    
                return $sql->fetchAll();
            }catch(Exception $e){
                echo $e->getMessage();
                exit;
            }
        }

    }
?>