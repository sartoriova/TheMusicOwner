<?php
    session_start();

    require_once "configs/utils.php";
    require_once "configs/verificaLogin.php";
        
    if(parametrosValidos($_SESSION, ["i"])){
        unset($_SESSION["i"]);
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="imagens/logotipo.png">
    <title>The Music Owner - Home</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/home.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>

<body>
    <header>
        <div class="left-icon">
            <img class="header-image" src="imagens/logotipo.png" alt="Imagem no Cabeçalho" width="80" height="97" style="margin-left: -10px; margin-top: 7px;">
        </div>

        <div class="center-icon">
            <h style="font-size: 50px;">THE MUSIC OWNER</h1>
        </div>

        <div class="right-icon">
            <a href="tabelaPontuacao.php" style="text-decoration: none; margin-right: 30px;">
                <svg width="60" height="70" viewBox="0 0 300 300" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <mask id="mask0_105_25" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="300" height="300">
                        <rect width="300" height="300" fill="#D9D9D9" />
                    </mask>
                    <g mask="url(#mask0_105_25)">
                        <path d="M56.25 262.5C51.25 262.5 46.875 260.625 43.125 256.875C39.375 253.125 37.5 248.75 37.5 243.75V56.25C37.5 51.25 39.375 46.875 43.125 43.125C46.875 39.375 51.25 37.5 56.25 37.5H243.75C248.75 37.5 253.125 39.375 256.875 43.125C260.625 46.875 262.5 51.25 262.5 56.25V243.75C262.5 248.75 260.625 253.125 256.875 256.875C253.125 260.625 248.75 262.5 243.75 262.5H56.25ZM56.25 106.25H243.75V56.25H56.25V106.25ZM56.25 175H243.75V125H56.25V175ZM56.25 243.75H243.75V193.75H56.25V243.75ZM75.9375 90.625V71.875H94.6875V90.625H75.9375ZM75.9375 159.375V140.625H94.6875V159.375H75.9375ZM75.9375 228.125V209.375H94.6875V228.125H75.9375Z" fill="white" />
                    </g>
                </svg>
            </a>

            <a href="perfil.php" style="text-decoration: none; margin-right: 30px;">
                <svg width="60" height="70" viewBox="0 0 235 245" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M99.9995 101.603C86.2495 101.603 74.9995 96.8795 66.2495 87.4331C57.4995 77.9868 53.1245 65.8414 53.1245 50.9971C53.1245 36.1528 57.4995 24.0075 66.2495 14.5612C74.9995 5.11479 86.2495 0.391602 99.9995 0.391602C113.75 0.391602 124.999 5.11479 133.749 14.5612C142.499 24.0075 146.874 36.1528 146.874 50.9971C146.874 65.8414 142.499 77.9868 133.749 87.4331C124.999 96.8795 113.75 101.603 99.9995 101.603ZM-0.000488281 209.899V178.186C-0.000488281 169.639 1.97868 162.329 5.93701 156.257C9.89534 150.184 14.9995 145.573 21.2495 142.424C35.2078 135.677 48.5933 130.617 61.4058 127.243C74.2183 123.869 87.0828 122.182 99.9995 122.182C112.916 122.182 125.729 123.925 138.437 127.411C151.145 130.898 164.47 135.924 178.412 142.49C184.933 145.667 190.161 150.274 194.097 156.311C198.032 162.347 199.999 169.639 199.999 178.186V209.899H-0.000488281ZM18.7495 189.656H181.249V178.186C181.249 174.587 180.26 171.157 178.281 167.896C176.302 164.635 173.854 162.217 170.937 160.642C157.604 153.67 145.416 148.891 134.374 146.304C123.333 143.718 111.875 142.424 99.9995 142.424C88.1245 142.424 76.562 143.718 65.312 146.304C54.062 148.891 41.8745 153.67 28.7495 160.642C25.8328 162.217 23.437 164.635 21.562 167.896C19.687 171.157 18.7495 174.587 18.7495 178.186V189.656ZM99.9995 81.3605C108.125 81.3605 114.843 78.4928 120.156 72.7575C125.468 67.0222 128.124 59.7688 128.124 50.9971C128.124 42.2255 125.468 34.972 120.156 29.2368C114.843 23.5015 108.125 20.6338 99.9995 20.6338C91.8745 20.6338 85.1558 23.5015 79.8433 29.2368C74.5308 34.972 71.8745 42.2255 71.8745 50.9971C71.8745 59.7688 74.5308 67.0222 79.8433 72.7575C85.1558 78.4928 91.8745 81.3605 99.9995 81.3605Z" fill="white" />
                </svg> 
            </a>

            <a href="logout.php">
                <svg width="60" height="70" viewBox="0 0 290 304" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <mask id="mask0_105_19" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="300" height="300">
                        <rect width="300" height="300" fill="#D9D9D9" />
                    </mask>
                    <g mask="url(#mask0_105_19)">
                        <path d="M56.25 262.5C51.25 262.5 46.875 260.625 43.125 256.875C39.375 253.125 37.5 248.75 37.5 243.75V56.25C37.5 51.25 39.375 46.875 43.125 43.125C46.875 39.375 51.25 37.5 56.25 37.5H147.188V56.25H56.25V243.75H147.188V262.5H56.25ZM208.125 204.688L194.688 191.25L226.562 159.375H117.188V140.625H225.938L194.062 108.75L207.5 95.3125L262.5 150.313L208.125 204.688Z" fill="white" />
                    </g>
                </svg>
            </a>
        </div>
    </header>

    <section><br>
        <form method="POST">
            <div class="top-buttons">
                <input type="button" value="POP" class="button1">
                <input type="button" value="ROCK" class="button2">
                <input type="button" value="GOSPEL" class="button3">
            </div><br>
            <div class="bottom-buttons">
                <input type="button" value="SERTANEJO" class="button4">
                <input type="button" value="MPB" class="button5">
                <input type="button" value="INDIE" class="button6">
            </div>
        </form>
    </section>

    <script>
        var inputs = document.querySelectorAll("form input[type='button']");

        inputs.forEach(function(input) {
            input.addEventListener("click", function(event) {
                var generoEscolhido = event.target.getAttribute("value");
                window.location.href = "armazenarGenero.php?genero=" + encodeURIComponent(generoEscolhido);
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
</body>

</html>