<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>

<body>
    <form method="POST">
        <input type="button" value="POP">
        <input type="button" value="ROCK">
        <input type="button" value="GOSPEL">
        <input type="button" value="SERTANEJO">
        <input type="button" value="MPB">
        <input type="button" value="INDIE">
    </form><br>

    <a href="logout.php">Logout</a><br>
    <a href="perfil.php">Perfil do usuário</a><br>
    <a href="tabelaPontuacao.php">Tabela de pontuação</a><br>

    <script>
        var inputs = document.querySelectorAll("form input[type='button']");

        inputs.forEach(function(input) {
            input.addEventListener("click", function(event) {
                var generoEscolhido = event.target.getAttribute("value");
                window.location.href = "armazenarGenero.php?genero=" + encodeURIComponent(generoEscolhido);
            });
        });
    </script>

    <?php
        session_start();
        
        require_once "configs/utils.php";
        require_once "verificaLogin.php";

        if(parametrosValidos($_SESSION, ["i"])){
            unset($_SESSION["i"]);
        }
    ?>
</body>

</html>