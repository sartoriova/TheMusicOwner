<?php
    session_start();

    require_once "configs/utils.php";

    if (parametrosValidos($_GET, ["genero"])) {
        $_SESSION["tipoGenero"] = $_GET["genero"];
    }
    
    header("Location: partida.php"); 
?>