<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="imagens/logotipo.png">
    <title>The Music Owner - Meu perfil</title>
    <link href="https://fonts.googleapis.com/css?family=Love+Ya Like A Sister&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Cuprum&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=PT+Mono&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/perfil.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
</head>
<body>
    <header>
        <a href="home.php">
            <div class="left-icon">
                <img class="header-image" src="imagens/logotipo.png" alt="Imagem no Cabeçalho" width="80" height="97" style="margin-left: -10px; margin-top: 7px;">
            </div>
        </a>

        <div class="center-icon">
            <h1 style="font-size: 50px;">THE MUSIC OWNER</h1>
        </div>

        <div class="right-icon">
            <a href="home.php"> 
                <img class="header-image" src="imagens/home.png" alt="#" width="70" height="70" style="margin-right: 20px;"> 
            </a>
        </div>
    </header>

    <section>
        <center><br>
            <?php
                session_start();

                require_once "model/Usuario.php";
                require_once "configs/utils.php";
                require_once "configs/verificaLogin.php";

                $idUsuario = $_SESSION["idUsuario"];

                $resultado = Usuario::listarUm($idUsuario);
            ?>

            <img id="fotoPerfil" src="<?php echo $resultado[0]['fotoPerfil'];?>" style="border-radius: 50%; width: 400px; height: 400px;">

            <table class="transparent">
                <thead>
                    <tr>
                        <th>Nome de usuário:</th>
                        <th> </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <?php
                                echo $resultado[0]['nomeUsuario'];
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php
                echo "<a href='editarUsuario.php?editarDados=$idUsuario'>";
            ?>
                    <button class="my-button" style="font-weight: bold;">Editar meus dados</button><br><br>
            <?php
                echo "</a>";
                echo "<a href='perfil.php?apagarConta=$idUsuario'>";
            ?>
                    <button class="my-button" style="font-weight: bold;">Apagar minha conta</button>
            <?php
                echo "</a>";
            ?>
        </center>
    </section>

    <?php
        if(parametrosValidos($_GET, ["apagarConta"])){
            $idUsuario = $_GET["apagarConta"];

            $resultado = Usuario::deletar($idUsuario);

            if($resultado){
                unset($_SESSION["idUsuario"]);
                header("Location: index.php");
            }
        }
    ?>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm"
        crossorigin="anonymous"></script>
</body>
</html>