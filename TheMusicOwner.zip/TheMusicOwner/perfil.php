<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Music Owner</title>
</head>
<body>
    <a href="home.php">Home</a><br>

    <div class="fotoPerfil">
        <?php
            session_start();

            require_once "model/Usuario.php";
            require_once "model/FotoPerfil.php";
            require_once "configs/utils.php";
            require_once "verificaLogin.php";

            $idUsuario = $_SESSION["idUsuario"];

            $resultado = Usuario::listarUm($idUsuario);
            //$i = array_rand($resultado);
        ?>

        <img id="fotoPerfil" src="<?php echo $resultado[0]['fotoPerfil']; ?>" style="border-radius: 50%; width: 200px; height: 200px;"><br>
        <!-- <button id="btnTroca">Experimentar outra</button> -->
    </div>

    <?php
        echo "Nome de usuário: " . $resultado[0]['nomeUsuario'] . "<br><br>";
        // echo "Senha: ****<br><br>";
        echo "<a href='perfil.php?apagarConta=$idUsuario'>Apagar minha conta</a>";

        if(parametrosValidos($_GET, ["apagarConta"])){
            $idUsuario = $_GET["apagarConta"];

            $resultado = Usuario::deletar($idUsuario);

            if($resultado){
                unset($_SESSION["idUsuario"]);
                header("Location: index.php");
            }
        }
    ?>
</body>
</html>